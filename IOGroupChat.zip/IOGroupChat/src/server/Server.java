/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author Junaed Younus Khan
 */
public class Server {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        ServerSocket welcomeSocket = new ServerSocket(6789);
        int id = 0;
        ArrayList<ClientInfo> clients = new ArrayList<ClientInfo>();

        while (true) {
            Socket connectionSocket = null;

            connectionSocket = welcomeSocket.accept();

            System.out.println("A new client has joined with socket : " + connectionSocket);
            
            
            
         
            DataInputStream dis = new DataInputStream(connectionSocket.getInputStream());
            DataOutputStream dos = new DataOutputStream(connectionSocket.getOutputStream());
            
            BufferedReader br = new BufferedReader(new InputStreamReader(dis));
            String n=br.readLine();
            System.out.println(n);
            ClientInfo ci = new ClientInfo(connectionSocket, dis, dos, ++id,n);
            
            for (int i = 0; i < clients.size(); i++) {
                System.out.println("done");
                ci.dos.writeBytes(ci.name+" just joined on the chat");
                
            }
            
            clients.add(ci);

            ClientHandler clientHandler = new ClientHandler(ci,clients);

            clientHandler.start();

        }

    }

}
