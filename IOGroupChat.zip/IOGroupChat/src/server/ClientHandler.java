/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Junaed Younus Khan
 */
public class ClientHandler extends Thread {

    ClientInfo ci;
    ArrayList<ClientInfo> clients;

    ClientHandler(ClientInfo ci, ArrayList<ClientInfo> clients) {
        this.ci = ci;
        this.clients = clients;
    }

    @Override
    public void run() {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(ci.dis));
            String msg=ci.name+" : "+br.readLine();
            for (int i = 0; i < clients.size(); i++) {
                System.out.println("im communicating: ");
                ci.dos.writeBytes(msg+'\n');
                
            }
            
        } catch (IOException ex) {
            
        }
       

    }
}

//
//
//System.out.println("thread started for client");
//        BufferedReader br = new BufferedReader(new InputStreamReader(dis));
//
//        while (true) {
//            try {
//                String sentenceFromClient = br.readLine();
//                System.out.println("from client- " + clientId + ": " + sentenceFromClient);
//
//                String upperSentence = sentenceFromClient.toUpperCase();
//                dos.writeBytes(upperSentence + '\n');
//
//            
//
//} catch (IOException ex) {
//                Logger.getLogger(ClientHandler.class
//.getName()).log(Level.SEVERE, null, ex);
//            }
//
//        }
