/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Junaed Younus Khan
 */
public class Client {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        
        Socket clientSocket = new Socket("localhost", 6789);
        

        
        DataInputStream dis = new DataInputStream(clientSocket.getInputStream()); 
        DataOutputStream dos = new DataOutputStream(clientSocket.getOutputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(dis));
        
        System.out.println("Enter Your Name: ");
        Scanner scanner = new Scanner(System.in);
        String name=scanner.nextLine();
        
        dos.writeBytes(name+'\n');
        
        ClientReader clientReader = new ClientReader(dis,dos,br);
        ClientWritter clientWritter = new ClientWritter(dis,dos,br);
        
        clientReader.start();
        clientWritter.start();
        
        
    }
}
